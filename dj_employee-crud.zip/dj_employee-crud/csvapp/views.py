from django.shortcuts import render,redirect
from .models import Employe
from .forms import EmployeForm
from django.contrib import messages

def index(request):
    return render(request,'apps/index.html')
def insert(request):
    if request.method=='POST':
        try:
            id1 = request.POST['EmplayeeID']
            name = request.POST['EmplayeeName']
            age = request.POST['EmplayeeAge']
            mob = request.POST['EmplayeeMobile']
            addres = request.POST['EmplayeeAddress']
            s = Employe.objects.create(emp_id=id1,emp_name = name , emp_age=age, emp_mobile=mob , emp_address=addres)
            #messages.info(request, 'Your Deatiles has been Added successfully!')
            return render(request,'apps/insert.html' ,{'Success':"Your Record Is Added"})
        except Exception as e:
            return render(request,'apps/insert.html' ,{'error':"somthing error"})
    return render(request,'apps/insert.html')
def show(request):
    emp = Employe.objects.all()
    return render(request,'apps/show.html',{"emp":emp})
def delete(request,id):
    emp = Employe.objects.get(id=id)
    emp.delete()
    return redirect('/show')
def update(request,id):
    emp = Employe.objects.get(id=id)
    if request.method=="POST":
        form = EmployeForm(request.POST,instance=emp)
        if form.is_valid():
            form.save()
        return redirect('/show')    
    return render(request,'apps/update.html',{'e':emp})
def home(request):
    return render(request ,'apps/home.html')