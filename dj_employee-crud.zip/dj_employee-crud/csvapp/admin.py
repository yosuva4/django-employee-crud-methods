from django.contrib import admin

from .models import Employe

class EmployeAdmin(admin.ModelAdmin):
	list_display = ['emp_id','emp_name','emp_age','emp_mobile','emp_address']

admin.site.register(Employe,EmployeAdmin)
